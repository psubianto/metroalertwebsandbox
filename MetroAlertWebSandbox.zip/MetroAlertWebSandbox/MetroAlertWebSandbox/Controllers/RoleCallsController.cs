﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MetroAlertWebSandbox.Controllers
{
    public class RoleCallsController : Controller
    {
        // GET: RoleCalls
        public ActionResult Index()
        {
            return View();
        }
    }
}