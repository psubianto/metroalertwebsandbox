﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MetroAlertWebSandbox.Controllers
{
    public class MyCallsController : Controller
    {
        // GET: MyCalls
        public ActionResult Index()
        {
            return View();
        }
    }
}